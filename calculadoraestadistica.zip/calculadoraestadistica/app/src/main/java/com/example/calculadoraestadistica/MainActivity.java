package com.example.calculadoraestadistica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    EditText Datos;
    Button Analizar_Datos;
    TextView Resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Datos = (EditText) findViewById(R.id.Datos);
        Analizar_Datos = (Button) findViewById(R.id.Analizar_Datos);
        Resultado = (TextView) findViewById(R.id.Resultado);


        Analizar_Datos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] datos = Datos.getText().toString().split(",");
                hacerOp(datos);
            }
        });
    }

    void hacerOp(String[] datos) {
        int[] arreglo = llenarArreglo(datos);
        if(arreglo != null) {

            //Media
            double media = promedio(arreglo);

            //Mediana
            double mediana = mediana(arreglo);

            //Moda
            double moda = moda(arreglo);

            //Rango
            double rango = rango(arreglo);

            //Desviacion
            double desviacion = desviacion(arreglo);

            Resultado.setText(" Moda del vector: " + moda);
            Resultado.append("\n");
            Resultado.append(" Media del vector: " + media);
            Resultado.append("\n");
            Resultado.append(" Mediana del vector: " + mediana);
            Resultado.append("\n");
            Resultado.append(" Rango del vector: " + rango);
            Resultado.append("\n");
            Resultado.append(" Desviacion del vector: " + desviacion);
            Resultado.append("\n");
            Resultado.append("\n");

            Resultado.append(reportaVector(arreglo));
        }else{
            Resultado.setText("¡ CANTIDAD DE DATOS INCORRECTA !");
        }
    }

    public static int[] llenarArreglo(String[] datos) {
        int elementos = Integer.parseInt(datos[0]);
        int i;
        int[] arreglo;
        arreglo = new int[elementos];
        Scanner sc = new Scanner(System.in);

        if(datos.length == (elementos + 1)){
            for (i = 0; i < elementos; i++) {
                arreglo[i] = Integer.parseInt(datos[i + 1]);
            }
        }else{
            return null;
        }

        return arreglo;
    }

    public static double promedio(int[] arreglo) {
        double prom = 0.0;
        for (int i = 0; i < arreglo.length; i++) {
            prom += arreglo[i];
        }

        return prom / (double) arreglo.length;
    }

    public static double desviacion(int[] arreglo) {
        double prom, sum = 0;
        int i, n = arreglo.length;
        prom = promedio(arreglo);

        for (i = 0; i < n; i++) {
            sum += Math.pow(arreglo[i] - prom, 2);
        }

        return Math.sqrt(sum / (double) n);
    }

    // 0 - Menor a Mayor, 1 - Mayor a menor
    public static int[] burbuja(int[] arreglo, int ord) {
        int i, j, n = arreglo.length, aux = 0;

        for (i = 0; i < n - 1; i++) {
            for (j = i + 1; j < n; j++) {
                if (ord == 0) {
                    if (arreglo[i] > arreglo[j]) {
                        aux = arreglo[j];
                        arreglo[j] = arreglo[i];
                        arreglo[i] = aux;
                    } else if (ord == 1) {
                        if (arreglo[i] < arreglo[j]) {
                            aux = arreglo[i];
                            arreglo[i] = arreglo[j];
                            arreglo[j] = aux;
                        }
                    }
                }
            }
        }

        return arreglo;
    }

    public static double mediana(int[] arreglo) {
        int pos = 0, n = arreglo.length;
        double temp = 0, temp0 = 0;
        // ordenar de menor a mayor
        arreglo = burbuja(arreglo, 0);

        temp = n / 2;
        if (n % 2 == 0) {
            pos = (int) temp;
            temp0 = (double) (arreglo[pos] / arreglo[pos + 1]);
        }
        if (n % 2 == 1) {
            pos = (int) (temp + 0.5);
            temp0 = (double) (arreglo[pos]);
        }

        return temp0;
    }

    public static int rango(int[] arreglo) {
        // ordenar de mayor a menor
        arreglo = burbuja(arreglo, 1);

        return arreglo[arreglo.length - 1] - arreglo[0];
    }

    public static int moda(int[] arreglo) {
        int i, j, moda = 0, n = arreglo.length, frec;
        int frecTemp, frecModa = 0, moda1 = -1;

        // ordenar de menor a mayor
        arreglo = burbuja(arreglo, 0);

        for (i = 0; i < n; i++) {
            frecTemp = 1;
            for (j = i + 1; j < n; j++) {
                if (arreglo[i] == arreglo[j]) {
                    frecTemp++;
                }
            }
            if (frecTemp > frecModa) {
                frecModa = frecTemp;
                moda1 = arreglo[i];
            }
        }
        return moda1;
    }

    public static String reportaVector(int[] arreglo) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < arreglo.length; i++) {
            result.append(arreglo[i] + " ");
        }
        return result.toString();
    }
}
